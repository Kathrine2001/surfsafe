function move(htmlPage){
  window.location.href=htmlPage;
  }


function togglePassword() {
    const passwordField =document.getElementById('password');
    const type = passwordField.type === 'password' ? 'text' : 'password';
    passwordField.type = type;
}

function newUser(){
  window.location.href='./newUser.html';
}

function quiz(){
  window.location.href='./⚠️.html';
}

function log_in(){
  window.location.href='./log_in.html';
}

function About_us(){
  window.location.href='./About_us.html';
}

function sos(){
  window.location.href='./sos.html';
}



function go_to(){
  window.location.href='/welcomePage.html';
}

 function end(){
   window.location.href='/welcomePage.html';
 }

