class Question{
  constructor(answers,  right_answer , div){
    this.answers = answers;
    this.right_answer = right_answer;
    this.div = div;
  
  }

check_answer(){

    if(this.answers[this.right_answer].checked){

       this.div.insertAdjacentHTML("beforebegin", "<p style='color: green;'>True!</p><img src='https://media4.giphy.com/media/LRlEuUoNPbjj2pGNEg/200w.webp?cid=ecf05e47g55bpds1ccrdwewejttr7f8ciy9i6e3f9lze33iw&rid=200w.webp&ct=g'/>", window.location.href ='./💰.html' ,
                                     setTimeout(() => {
                                       console.log("Delayed for 1 second.");
                                     }, 2*1000)
                                     );
    }else{
      this.div.insertAdjacentHTML("beforebegin", "<p style='color: red;'> Wrong!</p><img src='https://c.tenor.com/XhUZVtd5HdUAAAAC/smh-disappointed.gif'/>",window.location.href ='./🍑.html');

    }
    this.div.remove();
    }

}

var question1 = new Question([document.getElementById("a"),
                            document.getElementById("b"),
                            document.getElementById("c")],
                            2,
                            document.getElementById("all"));

